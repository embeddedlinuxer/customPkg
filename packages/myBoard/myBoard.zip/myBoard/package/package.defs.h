/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-G16
 */

#ifndef myBoard__
#define myBoard__



#endif /* myBoard__ */ 
